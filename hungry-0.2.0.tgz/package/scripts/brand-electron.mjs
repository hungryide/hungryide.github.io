/**
 * Renames the unpackaged Electron bundle to hungry.
 *
 * macOS reads three things from the running `.app` bundle rather than from
 * `app.setName()`: the menu bar title (`CFBundleName`), the name shown in
 * System Settings › Notifications (`CFBundleDisplayName`) and the identity
 * notification permissions are stored under (`CFBundleIdentifier`). In a `pnpm
 * dev` run that bundle is Electron's own, so all three say "Electron".
 *
 * Patching the bundle in place is the only way to fix that without packaging.
 * It is safe here because the dev bundle is ad-hoc, linker-signed with an
 * unbound Info.plist and no sealed resources, so editing those files leaves the
 * signature valid. The edit lives in node_modules and is undone by a reinstall,
 * which is why this runs from postinstall.
 *
 * Plain .mjs: Node refuses to strip TypeScript under node_modules, so a global
 * install cannot run a .ts postinstall script.
 */
import { readFileSync, statSync, copyFileSync, writeFileSync } from 'node:fs'
import { createRequire } from 'node:module'
import { dirname, join } from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'
import branding from '../src/shared/branding.json' with { type: 'json' }

const { APP_ID, APP_NAME } = branding

export { APP_ID, APP_NAME }

const escapeXml = (value) =>
  value.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')

/**
 * Sets a top-level string entry in an XML plist, adding the key when missing.
 *
 * Info.plist is a flat `<dict>` of interest here, so a targeted edit keeps the
 * rest of the file — including Electron's own keys — byte for byte intact.
 */
export const setPlistString = (plist, key, value) => {
  const escapedKey = escapeXml(key).replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
  const entry = new RegExp(`(<key>${escapedKey}</key>\\s*<string>)([^<]*)(</string>)`)
  const match = entry.exec(plist)
  if (match) {
    if (match[2] === escapeXml(value)) return plist
    return plist.replace(entry, `$1${escapeXml(value)}$3`)
  }

  const closing = plist.lastIndexOf('</dict>')
  if (closing === -1) throw new Error('Info.plist has no <dict> to extend')
  const added = `\t<key>${escapeXml(key)}</key>\n\t<string>${escapeXml(value)}</string>\n`
  return `${plist.slice(0, closing)}${added}${plist.slice(closing)}`
}

/** Reads a top-level string entry, for reporting what a patch changed. */
export const plistString = (plist, key) => {
  const escapedKey = key.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
  const match = new RegExp(`<key>${escapedKey}</key>\\s*<string>([^<]*)</string>`).exec(plist)
  return match ? match[1] : null
}

/** The `.app` the `electron` package would launch, or null when it has no binary yet. */
export const bundlePath = () => {
  try {
    const require = createRequire(import.meta.url)
    const packageDir = dirname(require.resolve('electron/package.json'))
    const relative = readFileSync(join(packageDir, 'path.txt'), 'utf8').trim()
    // path.txt points at the executable inside the bundle.
    const marker = relative.indexOf('.app/')
    if (marker === -1) return null
    const bundle = join(packageDir, 'dist', relative.slice(0, marker + 4))
    return statSync(bundle).isDirectory() ? bundle : null
  } catch {
    return null
  }
}

const sameFile = (a, b) => {
  try {
    return readFileSync(a).equals(readFileSync(b))
  } catch {
    return false
  }
}

/** Applies the branding, returning a line per change for the install log. */
export const brand = (bundle, repoRoot) => {
  const changes = []
  const plistFile = join(bundle, 'Contents', 'Info.plist')
  const before = readFileSync(plistFile, 'utf8')

  const wanted = [
    ['CFBundleName', APP_NAME],
    ['CFBundleDisplayName', APP_NAME],
    ['CFBundleIdentifier', APP_ID]
  ]

  let after = before
  for (const [key, value] of wanted) {
    const current = plistString(after, key)
    after = setPlistString(after, key, value)
    if (current !== value) changes.push(`${key}: ${current ?? '(unset)'} → ${value}`)
  }
  if (after !== before) writeFileSync(plistFile, after, 'utf8')

  // The banner and the app switcher take their icon from the bundle, which
  // app.dock.setIcon() cannot reach.
  const iconName = plistString(after, 'CFBundleIconFile') ?? 'electron.icns'
  const iconFile = join(bundle, 'Contents', 'Resources', iconName)
  const source = join(repoRoot, 'resources', 'icon.icns')
  try {
    statSync(source)
    if (!sameFile(source, iconFile)) {
      copyFileSync(source, iconFile)
      changes.push(`${iconName}: replaced with resources/icon.icns`)
    }
  } catch {
    // No icon in the repo, or an Electron layout without one: names still apply.
  }

  return changes
}

const runningAsScript = () => {
  const entry = process.argv[1]
  return typeof entry === 'string' && pathToFileURL(entry).href === import.meta.url
}

if (runningAsScript()) {
  // An install must not fail over cosmetics.
  try {
    if (process.platform !== 'darwin') {
      // Windows takes its notification identity from app.setAppUserModelId(),
      // which the main process sets at startup, and Linux from the .desktop file.
      process.exit(0)
    }

    const bundle = bundlePath()
    if (!bundle) {
      console.log('[hungry] no Electron bundle to brand yet, skipping')
      process.exit(0)
    }

    const repoRoot = dirname(dirname(fileURLToPath(import.meta.url)))
    const changes = brand(bundle, repoRoot)
    if (changes.length === 0) {
      console.log('[hungry] dev Electron bundle already branded')
    } else {
      console.log(`[hungry] branded the dev Electron bundle:\n  ${changes.join('\n  ')}`)
      console.log('[hungry] macOS treats this as a new app identity in the Dock')
    }
  } catch (error) {
    console.warn('[hungry] could not brand the dev Electron bundle:', error)
  }
}
