/**
 * Install-time setup.
 *
 * Three warm-ups, none of which may fail an install:
 *
 *   1. the Electron binary. The `electron` package downloads it on first
 *      require, so fetching it here only moves the wait out of the first launch.
 *   2. the native terminal. node-pty is checked, never compiled: 1.1.0 is an
 *      N-API addon shipping prebuilt binaries for macOS and Windows, and N-API
 *      keeps a binary compatible across Node and Electron ABIs. Rebuilding it
 *      (`electron-rebuild -f -w node-pty`, what this script replaced) required
 *      Python and a C++ toolchain to produce a file equivalent to the one npm
 *      already unpacked, so an install failed on machines without them.
 *   3. on macOS, the dev bundle's name and icon.
 *
 * Nothing here is load-bearing. npm 12 blocks dependency install scripts unless
 * they are allow-listed, so a global install may never run this file; the parts
 * that matter repeat themselves on first launch from `bin/hungry.mjs`.
 *
 * Plain .mjs: Node refuses to strip TypeScript under node_modules, so a global
 * install cannot run a .ts install script.
 */
import { spawnSync } from 'node:child_process'
import { existsSync, readFileSync } from 'node:fs'
import { createRequire } from 'node:module'
import { dirname, join } from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'

const nodeRequire = createRequire(import.meta.url)

/** The installed directory of a package, or null when it cannot be resolved. */
const packageDir = (name) => {
  try {
    return dirname(nodeRequire.resolve(`${name}/package.json`))
  } catch {
    return null
  }
}

/**
 * The Electron executable this install would launch, or null when the binary
 * has not been downloaded yet. `path.txt` is written by Electron's installer.
 */
export const electronBinary = () => {
  const dir = packageDir('electron')
  if (!dir) return null
  try {
    const relative = readFileSync(join(dir, 'path.txt'), 'utf8').trim()
    const binary = join(dir, 'dist', relative)
    return existsSync(binary) ? binary : null
  } catch {
    return null
  }
}

/** Downloads the Electron binary unless it is already there. */
export const ensureElectron = () => {
  const existing = electronBinary()
  if (existing) return { ok: true, detail: existing }

  const dir = packageDir('electron')
  if (!dir) return { ok: false, detail: 'the electron package is not installed' }

  const result = spawnSync(process.execPath, [join(dir, 'install.js')], { stdio: 'inherit' })
  const binary = electronBinary()
  if (result.status === 0 && binary) return { ok: true, detail: binary }

  const reason = result.error?.message ?? `install.js exited with ${result.status ?? 'no status'}`
  return { ok: false, detail: reason }
}

/**
 * Reports whether the pty addon is present and loadable.
 *
 * The prebuilt binary is N-API, so a successful load in this Node process
 * answers for Electron's process too — which is why no rebuild step is needed.
 */
export const nativeTerminal = () => {
  const dir = packageDir('node-pty')
  if (!dir) return { ok: false, detail: 'node-pty is not installed' }

  // node-pty looks in build/ first and falls back to its shipped prebuilds.
  const candidates = [
    join(dir, 'build', 'Release', 'pty.node'),
    join(dir, 'build', 'Debug', 'pty.node'),
    join(dir, 'prebuilds', `${process.platform}-${process.arch}`, 'pty.node')
  ]
  const binary = candidates.find((candidate) => existsSync(candidate))
  if (!binary) {
    return { ok: false, detail: `no pty binary for ${process.platform}-${process.arch}` }
  }

  try {
    nodeRequire('node-pty')
  } catch (error) {
    return { ok: false, detail: error instanceof Error ? error.message : String(error) }
  }
  return { ok: true, detail: binary }
}

const runningAsScript = () => {
  const entry = process.argv[1]
  return typeof entry === 'string' && pathToFileURL(entry).href === import.meta.url
}

if (runningAsScript()) {
  const here = dirname(fileURLToPath(import.meta.url))

  if (process.env['HUNGRY_SKIP_POSTINSTALL'] === '1') {
    console.log('[hungry] HUNGRY_SKIP_POSTINSTALL=1, skipping install-time setup')
    process.exit(0)
  }

  const electron = ensureElectron()
  if (electron.ok) {
    console.log(`[hungry] Electron binary ready: ${electron.detail}`)
  } else {
    console.warn(
      `[hungry] could not download the Electron binary now (${electron.detail}).\n` +
        '[hungry] it is downloaded again on the first `hungry` or `pnpm dev` run.'
    )
  }

  const terminal = nativeTerminal()
  if (terminal.ok) {
    console.log(`[hungry] terminal addon ready: ${terminal.detail}`)
  } else {
    console.warn(
      `[hungry] the terminal addon is unavailable (${terminal.detail}).\n` +
        '[hungry] the app still runs; the terminal pane reports the same error.\n' +
        '[hungry] to build it from source, install Python 3 and a C++ toolchain, then run:\n' +
        '[hungry]   npm rebuild node-pty --build-from-source'
    )
  }

  // Cosmetic, macOS only, and it exits 0 everywhere else.
  spawnSync(process.execPath, [join(here, 'brand-electron.mjs')], { stdio: 'inherit' })

  // A warm-up must never be the reason an install fails.
  process.exit(0)
}
